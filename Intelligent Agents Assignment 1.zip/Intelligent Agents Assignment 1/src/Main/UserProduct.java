package Main;

public class UserProduct extends Product{
	private String userID;

	public UserProduct( String userID,String productID, double score) {
		super(productID, score);
		this.userID = userID;
	}
	


	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	@Override
	public String toString() {
		return "UserProduct [userID=" + userID + ", toString()=" + super.toString() + "]" +"\n";
	}
	
	


}
