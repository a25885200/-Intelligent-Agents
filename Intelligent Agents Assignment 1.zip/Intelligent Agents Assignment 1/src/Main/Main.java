package Main;

import java.util.*;

public class Main {
	public static UserProduct users[] = new UserProduct[30];
	public static ArrayList<UserProduct> requestlist = new ArrayList<UserProduct>();

	public static void main(String[] args) {
		Update update = new Update();
		Request request = new Request();
		update.updating("UP20190101121111",users);
		update.updating("UP20190101121112",users);
		request.requesting("RR20190101131111", users, requestlist);
		

	}

	
}
