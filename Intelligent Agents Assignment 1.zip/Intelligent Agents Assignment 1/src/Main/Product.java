package Main;

public class Product {
	private String productID;
	private double score;

	public Product(String productID, double score) {
		this.productID = productID;
		this.score = score;
	}

	public String getProductID() {
		return productID;
	}

	public void setProductID(String productID) {
		this.productID = productID;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	@Override
	public String toString() {
		return "Product [productID=" + productID + ",score=" + score + "]";
	}

}
