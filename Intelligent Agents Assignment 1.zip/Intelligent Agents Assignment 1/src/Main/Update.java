package Main;

import java.io.IOException;

public class Update {
	
	public void updating(String path, UserProduct[] users) {
		CSVReader cr = new CSVReader(users);
		CSVWriter cw =new CSVWriter(users);
		CSVMove cm = new CSVMove();
		try {
			System.out.println("read " + path + ".csv");
			cr.readupdate(path);
			if (cm.moveFile(path)) {
				System.out.println("move " + path + " to processed success!");
			} else {
				System.out.println("Move " + path + " to  processed fail!");
			}
			cw.writeCurrentModel();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

	}

}
