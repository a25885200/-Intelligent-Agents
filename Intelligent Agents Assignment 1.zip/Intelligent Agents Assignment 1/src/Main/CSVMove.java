package Main;

import java.io.File;

public class CSVMove {

	public CSVMove() {
		// TODO Auto-generated constructor stub
	}

	public boolean moveFile(String sourcePath) {
		String path1 ="C:\\Intelligent Agents Assignment 1\\file\\input\\"
				+ sourcePath +".csv";
		File fileToMove = new File(path1);

		return fileToMove.renameTo(new File("C:\\Intelligent Agents Assignment 1\\file\\Processed\\"+ sourcePath+".csv"));
	}
}
