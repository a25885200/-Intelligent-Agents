package Main;

import java.io.*;
import java.util.ArrayList;

public class CSVWriter {
	private UserProduct users[];
	private ArrayList<UserProduct> requestlist;

	public CSVWriter(UserProduct[] users) {
		this.users = users;
	}

	public CSVWriter(UserProduct[] users, ArrayList<UserProduct> requestlist) {
		this.users = users;
		this.requestlist = requestlist;
	}

	public void writeCurrentModel() throws IOException {
		try (PrintWriter writer = new PrintWriter(new File(
				"C:\\Intelligent Agents Assignment 1\\file\\output\\currentModel.csv"))) {
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < users.length; i++) {
				if (users[i] != null) {
					sb.append(users[i].getUserID());
					sb.append(",");
					sb.append(users[i].getProductID());
					sb.append(",");
					sb.append(users[i].getScore());
					sb.append("\n");
				} else
					break;

			}
			writer.write(sb.toString());
			System.out.println("current model genarate complete!");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void writeRRlist(String path,String UserId) {
		try (PrintWriter writer = new PrintWriter(new File(
				"C:\\Intelligent Agents Assignment 1\\file\\output\\"
						+ path + "out.csv"))) {
			int i = (int) (Math.random()*requestlist.size()/2);
			StringBuilder sb2 = new StringBuilder();
			sb2.append(UserId);
			sb2.append(",");
			sb2.append(requestlist.get(i).getProductID());
			sb2.append("&");
			i = (int) (Math.random()*requestlist.size()/2);
			sb2.append(requestlist.get(i).getProductID());
			writer.write(sb2.toString());
			System.out.println("recommanded request list genarate complete!");

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
