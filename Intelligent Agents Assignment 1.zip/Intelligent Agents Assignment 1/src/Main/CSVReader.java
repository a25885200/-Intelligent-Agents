package Main;

import java.io.*;
import java.util.*;

public class CSVReader {
	private UserProduct users[];
	private ArrayList<UserProduct> requestlist;

	public CSVReader(UserProduct[] users) {
		this.users = users;
	}

	public CSVReader(UserProduct[] users, ArrayList<UserProduct> requestlist) {
		this.users = users;
		this.requestlist = requestlist;
	}

	public UserProduct[] getUsers() {
		return users;
	}

	public void setUsers(UserProduct[] users) {
		this.users = users;
	}

	public List<UserProduct> getRequest() {
		return requestlist;
	}

	public void setRequest(ArrayList<UserProduct> requestlist) {
		this.requestlist = requestlist;
	}

	public void readupdate(String path) throws IOException {
		String line = null;
		try (BufferedReader reader = new BufferedReader(new FileReader(
				"C:\\Intelligent Agents Assignment 1\\file\\input\\"
						+ path + ".csv"))) {
			while ((line = reader.readLine()) != null) {
				{
					String item[] = line.split(",");
					for (int i = 0; i < users.length; i++) {
						if (users[i] != null) {
							if (Integer.parseInt(users[i].getUserID()) == Integer.parseInt(item[0])
									&& Integer.parseInt(users[i].getProductID()) == Integer.parseInt(item[1])) {
								System.out.print(users[i]);
								users[i] = new UserProduct(item[0], item[1], Double.parseDouble(item[2]));
								System.out.println("change to " + users[i]);
								break;
							}
						} else {
							users[i] = new UserProduct(item[0], item[1], Double.parseDouble(item[2]));
							System.out.print("add new " + users[i]);
							break;
						}
					}
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {

		}

	}

	public String read(String path, String act) throws IOException {
		String userId = null;
		String line = null;
		try (BufferedReader reader = new BufferedReader(new FileReader(
				"C:\\Intelligent Agents Assignment 1\\file\\input\\"
						+ path + ".csv"))) {
			while ((line = reader.readLine()) != null) {
				String item[] = line.split(",");
				for (int j = 0; j < users.length; j++) {
					if (users[j] == null) {
						break;
					} else {
						if (Integer.parseInt(item[0]) != Integer.parseInt(users[j].getUserID())) {
							requestlist.add(users[j]);
							System.out.print(users[j]);
						} else if (Integer.parseInt(item[0]) == Integer.parseInt(users[j].getUserID())) {
							userId = item[0];
						}
					}

				}
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return userId;
	}

}
