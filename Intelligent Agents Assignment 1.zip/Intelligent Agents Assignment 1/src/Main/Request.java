package Main;

import java.io.IOException;
import java.util.*;

public class Request {
	public void requesting(String path, UserProduct[] users, ArrayList<UserProduct> requestlist) {
		CSVReader cr = new CSVReader(users, requestlist);
		CSVMove cm = new CSVMove();
		try {
			String userId = cr.read(path, "request");
			System.out.println("sorting request list");
			cr.getRequest().sort(Comparator.<UserProduct, Double>comparing(p -> p.getScore()));
			Collections.reverse(cr.getRequest());
			
			System.out.print(cr.getRequest());
			CSVWriter cw = new CSVWriter(users, requestlist);
			cm.moveFile(path);
			
			cw.writeRRlist(path,userId);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
